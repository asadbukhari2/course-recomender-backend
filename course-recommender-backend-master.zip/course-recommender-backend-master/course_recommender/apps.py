from django.apps import AppConfig


class CourseRecommenderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'course_recommender'
